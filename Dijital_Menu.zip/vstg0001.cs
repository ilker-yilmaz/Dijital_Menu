﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class yemek_işlemleri : DevExpress.XtraEditors.XtraForm
    {
        //bağlantı cümleciğini yazıyoruz
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-UI4IIME2; Initial Catalog=DijitalMenu; Integrated Security=True");


        public yemek_işlemleri()
        {
            InitializeComponent();
        }

        private void yemek_işlemleri_Load(object sender, EventArgs e)
        {
            //listeleyi çağırıyoruz.
            Listele();
            //tablodaki verilerin değiştirilmemesi için sadece okunabilir olarak ayarlıyoruz.
            gridView1.OptionsBehavior.ReadOnly = true;
        }

        private void btnEkle_Click(object sender, EventArgs e)
        {
            Ekle();
        }

        private void btnGuncelle_Click(object sender, EventArgs e)
        {
            //güncelleme işlemini gerçekleşrtiriyoruz.
            if (btnGuncelle.Text == "Seçili Veriyi Güncelle")
            {
                Guncelle();
            }
            //btnGuncelle.Text = "Güncelle";
            BilgiCek();
        }

        private void btnSil_Click(object sender, EventArgs e)
        {
            Sil();
        }

        private void btnTemizleSil_Click(object sender, EventArgs e)
        {
            Listele();
        }
        public void Listele()
        {
            //öncelikle çalıştıracağımız komutu oluşturalım
            string komut = "select * from  yemek";//yemek tablomuzdaki tüm verileri getir.
            SqlDataAdapter da = new SqlDataAdapter(komut, conn);
            DataSet ds = new DataSet();
            da.Fill(ds);
            gridControl1.DataSource = ds.Tables[0];

            txtYemekAdi.Text = " ";
            txtFiyat.Text = " ";
            txtAciklama.Text = " ";
            cbKategori.SelectedItem = 0;
            

        }

        public void Ekle()
        {
            conn.Open();
            SqlCommand cmd = new SqlCommand("insert into yemek (YemekAdi,YemekKategorisi,YemekFiyati,Aciklama)" +
                "values(@ad,@kategori,@fiyat,@aciklama)", conn);
            cmd.Parameters.AddWithValue("@ad", txtYemekAdi.Text);
            cmd.Parameters.AddWithValue("@kategori", cbKategori.SelectedItem);
            cmd.Parameters.AddWithValue("@fiyat", txtFiyat.Text);
            cmd.Parameters.AddWithValue("@aciklama", txtAciklama.Text);
            
            cmd.ExecuteNonQuery();
            conn.Close();
            Listele();

            
        }

        public void BilgiCek()
        {
            //ilk tıkladığımız zaman o satırdaki tüm bilgileri sol kısımdaki boşluklara aktarmamız lazım öncelikle.
            txtYemekAdi.Text = gridView1.GetFocusedRowCellValue("YemekAdi").ToString();
            txtFiyat.Text = gridView1.GetFocusedRowCellValue("YemekFiyati").ToString();
            txtAciklama.Text = gridView1.GetFocusedRowCellValue("Aciklama").ToString();
            cbKategori.Text = gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString();

            Kategoriler();

            btnGuncelle.Text = "Seçili Veriyi Güncelle";
        }

        public void Guncelle()
        {
            string id = gridView1.GetFocusedRowCellValue("ID").ToString();

            conn.Open();//bağlantımızı açtık.
            //çalıştıracak komutumuzu yapalım
            SqlCommand cmd = new SqlCommand(
                "update yemek set YemekAdi='" + txtYemekAdi.Text +
                "', YemekFiyati='" + txtFiyat.Text +
                "', YemekKategorisi='" + cbKategori.SelectedText +
                "', Aciklama='" + txtAciklama.Text +
                "' where ID='" + id + "'", conn);

            cmd.ExecuteNonQuery();
            conn.Close();
            Listele();

            btnGuncelle.Text = "Güncelle";

        }
        public void Sil()
        {
            //silme işlemini gerçekleştirmeden önce onay istiyoruz.
            DialogResult onay = MessageBox.Show("kaydı silmek istediğinizden emin misiniz?", "Onay Kutusu", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            if (onay == DialogResult.Yes)
            {
                //tıklaığımız satırdaki ifadeyi almamız gerekiyor.
                conn.Open();

                string id = gridView1.GetFocusedRowCellValue("ID").ToString();
                SqlCommand cmd = new SqlCommand("delete from yemek where ID='" + id + "'", conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                Listele();

            }


        }

        private void Kategoriler()
        {
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Çorbalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Mezeler")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Balık ve Deniz")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Et Yemekleri")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Kebaplar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Köfteler")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Tavuk ve Hindi")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Yumurta Yemekleri")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Börek ve Poğaçalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Mantı ve Makarnalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Pilavlar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Pizzalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Dolmalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Kuru Baklagiller")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Salatalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Sebze Yemekleri")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Zeytinyağlılar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Dondurmalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Hamur Tatlıları")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Helvalar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Komposto Hoşaf")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Meyve Tatlıları")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Reçeller")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Sütlü Tatlılar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Bisküvi Kurabiye")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Kanepe ve Ekmek")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Kekler")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
            if (gridView1.GetFocusedRowCellValue("YemekKategorisi").ToString() == "Pasta Turta Tatlılar")
            {
                cbKategori.SelectedIndex = 0;
            }
            else
            {
                cbKategori.SelectedIndex = 1;
            }
        }

        private void gridControl1_Click(object sender, EventArgs e)
        {

        }

        private void txtAciklama_TextChanged(object sender, EventArgs e)
        {

        }
    }
}