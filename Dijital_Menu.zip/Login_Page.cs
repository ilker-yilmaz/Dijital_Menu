﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Login_Page : DevExpress.XtraEditors.XtraForm
    {
        //SQL ile bağlantı

        //bağlantı cümleciğini yazıyoruz
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-UI4IIME2; Initial Catalog=DijitalMenu; Integrated Security=True");

        public Login_Page()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            Kayitli_mi();

        }

        public void Kayitli_mi()
        {
            string k_adi = textBox_K_adi.Text;
            string password = textBox_password.Text;
            bool kayitli_mi = false;

            conn.Open();//bağlantıyı açtık
            //öncelikle sorgu cümleciğini (query) yazıyoruz
            SqlCommand cmd = new SqlCommand("Select * from login ", conn);//kayıtları getirecek olan query' i çalıştır ve sonucu ver
            SqlDataReader dr = cmd.ExecuteReader();//gelen sonucu yazdır

            //kontrol işlemleri
            //öncelikle datareader okuma işlemi yapıyor mu? bi kontrol edelim.
            while (dr.Read())//dr'deki tüm ifadeyi oku
            {
                if ((k_adi != dr["K_adi"].ToString()) || (password != dr["Sifre"].ToString()))
                {
                    kayitli_mi = false;
                }
                else
                {
                    kayitli_mi = true; //yani böyle bir kayıt olduğu doğrulanmış olacak
                    break;//kayıt var ise döngüden çıkmış olacak
                }

            }
            conn.Close();//bağlantı ile işimiz kalmadı, kapatıyoruz.

            if (kayitli_mi == true)
            {
                Form1 rbn = new Form1();
                rbn.Show();
                this.Hide();
            }
            else MessageBox.Show("Kullanıcı adı veya şifre yanlış..");
        }

        private void simpleButton2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }



        private void Login_Page_Load(object sender, EventArgs e)
        {

        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            SifremiUnuttum sf = new SifremiUnuttum();
            sf.Show();
            this.Hide();
        }

        private void simpleButton1_Click_1(object sender, EventArgs e)
        {
            if (textBox_password.Properties.UseSystemPasswordChar)
            {
                textBox_password.Properties.UseSystemPasswordChar = false;
            }
            else
            {
                textBox_password.Properties.UseSystemPasswordChar = true;
            }

        }

        private void checkEdit1_CheckedChanged(object sender, EventArgs e)
        {
            //otomatik doldur

            conn.Open();//bağlantıyı açtık
            //öncelikle sorgu cümleciğini (query) yazıyoruz
                SqlCommand cmd = new SqlCommand("Select * from login ", conn);//kayıtları getirecek olan query' i çalıştır ve sonucu ver
                SqlDataReader dr = cmd.ExecuteReader();//gelen sonucu yazdır
            if (checkEdit1.Checked)
            {
                
                while (dr.Read())
                {
                    string kullanici_adi = dr["K_adi"].ToString();
                    //string sifre = dr["Sifre"].ToString();//güvenlik amacıyla şifreyi yazdırmıyoruz.

                    textBox_K_adi.Text = kullanici_adi;
                    //textBox_password.Text = sifre;//güvenlik amacıyla şifreyi yazdırmıyoruz.

                }

            }
            else
            {
                textBox_K_adi.Text = "";
                //textBox_password.Text = "";//güvenlik amacıyla şifreyi yazdırmıyoruz.
            }

            conn.Close();//bağlantı ile işimiz kalmadı, kapatıyoruz.
        }
    }
}