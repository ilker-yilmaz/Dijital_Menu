﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace $safeprojectname$
{
    public partial class hizliErisim : DevExpress.XtraEditors.XtraForm
    {
        public hizliErisim()
        {
            InitializeComponent();
        }

        private void navBarControl1_Click(object sender, EventArgs e)
        {

        }

        private void hizliErisim_Load(object sender, EventArgs e)
        {
            yemek_işlemleri ymk = new yemek_işlemleri();
            ymk.Listele();
        }
    }
}