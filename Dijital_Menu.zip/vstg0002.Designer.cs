﻿namespace $safeprojectname$
{
    partial class yemek_işlemleri
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(yemek_işlemleri));
            DevExpress.XtraGrid.GridLevelNode gridLevelNode1 = new DevExpress.XtraGrid.GridLevelNode();
            this.xtraTabControl1 = new DevExpress.XtraTab.XtraTabControl();
            this.xtraTabPage2 = new DevExpress.XtraTab.XtraTabPage();
            this.btnSil = new DevExpress.XtraEditors.SimpleButton();
            this.btnTemizleSil = new DevExpress.XtraEditors.SimpleButton();
            this.btnGuncelle = new DevExpress.XtraEditors.SimpleButton();
            this.btnEkle = new DevExpress.XtraEditors.SimpleButton();
            this.txtAciklama = new System.Windows.Forms.RichTextBox();
            this.cbKategori = new DevExpress.XtraEditors.ComboBoxEdit();
            this.txtFiyat = new DevExpress.XtraEditors.TextEdit();
            this.txtYemekAdi = new DevExpress.XtraEditors.TextEdit();
            this.lblAciklama = new System.Windows.Forms.Label();
            this.lblFiyat = new System.Windows.Forms.Label();
            this.lblKategori = new System.Windows.Forms.Label();
            this.lblYemekAdi = new System.Windows.Forms.Label();
            this.gridControl1 = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).BeginInit();
            this.xtraTabControl1.SuspendLayout();
            this.xtraTabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbKategori.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFiyat.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYemekAdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // xtraTabControl1
            // 
            this.xtraTabControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.xtraTabControl1.Location = new System.Drawing.Point(0, 0);
            this.xtraTabControl1.Name = "xtraTabControl1";
            this.xtraTabControl1.SelectedTabPage = this.xtraTabPage2;
            this.xtraTabControl1.Size = new System.Drawing.Size(300, 535);
            this.xtraTabControl1.TabIndex = 0;
            this.xtraTabControl1.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.xtraTabPage2});
            // 
            // xtraTabPage2
            // 
            this.xtraTabPage2.Controls.Add(this.btnSil);
            this.xtraTabPage2.Controls.Add(this.btnTemizleSil);
            this.xtraTabPage2.Controls.Add(this.btnGuncelle);
            this.xtraTabPage2.Controls.Add(this.btnEkle);
            this.xtraTabPage2.Controls.Add(this.txtAciklama);
            this.xtraTabPage2.Controls.Add(this.cbKategori);
            this.xtraTabPage2.Controls.Add(this.txtFiyat);
            this.xtraTabPage2.Controls.Add(this.txtYemekAdi);
            this.xtraTabPage2.Controls.Add(this.lblAciklama);
            this.xtraTabPage2.Controls.Add(this.lblFiyat);
            this.xtraTabPage2.Controls.Add(this.lblKategori);
            this.xtraTabPage2.Controls.Add(this.lblYemekAdi);
            this.xtraTabPage2.Name = "xtraTabPage2";
            this.xtraTabPage2.Size = new System.Drawing.Size(293, 501);
            this.xtraTabPage2.Text = "Hızlı Erişim";
            // 
            // btnSil
            // 
            this.btnSil.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSil.ImageOptions.Image")));
            this.btnSil.Location = new System.Drawing.Point(34, 448);
            this.btnSil.Name = "btnSil";
            this.btnSil.Size = new System.Drawing.Size(94, 47);
            this.btnSil.TabIndex = 54;
            this.btnSil.Text = "Sil";
            this.btnSil.Click += new System.EventHandler(this.btnSil_Click);
            // 
            // btnTemizleSil
            // 
            this.btnTemizleSil.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnTemizleSil.ImageOptions.Image")));
            this.btnTemizleSil.Location = new System.Drawing.Point(156, 448);
            this.btnTemizleSil.Name = "btnTemizleSil";
            this.btnTemizleSil.Size = new System.Drawing.Size(130, 47);
            this.btnTemizleSil.TabIndex = 53;
            this.btnTemizleSil.Text = "Temizle_Listele";
            this.btnTemizleSil.Click += new System.EventHandler(this.btnTemizleSil_Click);
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnGuncelle.ImageOptions.Image")));
            this.btnGuncelle.Location = new System.Drawing.Point(156, 382);
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.Size = new System.Drawing.Size(130, 42);
            this.btnGuncelle.TabIndex = 52;
            this.btnGuncelle.Text = "Güncelle";
            this.btnGuncelle.Click += new System.EventHandler(this.btnGuncelle_Click);
            // 
            // btnEkle
            // 
            this.btnEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnEkle.ImageOptions.Image")));
            this.btnEkle.Location = new System.Drawing.Point(34, 382);
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.Size = new System.Drawing.Size(94, 42);
            this.btnEkle.TabIndex = 51;
            this.btnEkle.Text = "Ekle";
            this.btnEkle.Click += new System.EventHandler(this.btnEkle_Click);
            // 
            // txtAciklama
            // 
            this.txtAciklama.Location = new System.Drawing.Point(84, 232);
            this.txtAciklama.Name = "txtAciklama";
            this.txtAciklama.Size = new System.Drawing.Size(202, 101);
            this.txtAciklama.TabIndex = 50;
            this.txtAciklama.Text = "";
            this.txtAciklama.TextChanged += new System.EventHandler(this.txtAciklama_TextChanged);
            // 
            // cbKategori
            // 
            this.cbKategori.EditValue = "Çorba";
            this.cbKategori.Location = new System.Drawing.Point(83, 91);
            this.cbKategori.Name = "cbKategori";
            this.cbKategori.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cbKategori.Properties.Items.AddRange(new object[] {
            "Çorbalar",
            "Mezeler",
            "Balık ve Deniz",
            "Et Yemekleri",
            "Kebaplar",
            "Köfteler",
            "Tavuk ve Hindi",
            "Yumurta Yemekleri",
            "Börek ve Poğaçalar",
            "Mantı ve Makarnalar",
            "Pilavlar",
            "Pizzalar",
            "Dolmalar",
            "Kuru Baklagiller",
            "Salatalar",
            "Sebze Yemekleri",
            "Zeytinyağlılar",
            "Dondurmalar",
            "Hamur Tatlıları",
            "Helvalar",
            "Komposto Hoşaf",
            "Meyve Tatlıları",
            "Reçeller",
            "Sütlü Tatlılar",
            "Bisküvi Kurabiye",
            "Kanepe ve Ekmek",
            "Kekler",
            "Pasta Turta Tatlılar"});
            this.cbKategori.Size = new System.Drawing.Size(203, 22);
            this.cbKategori.TabIndex = 48;
            // 
            // txtFiyat
            // 
            this.txtFiyat.Location = new System.Drawing.Point(83, 159);
            this.txtFiyat.Name = "txtFiyat";
            this.txtFiyat.Size = new System.Drawing.Size(203, 22);
            this.txtFiyat.TabIndex = 45;
            // 
            // txtYemekAdi
            // 
            this.txtYemekAdi.Location = new System.Drawing.Point(83, 30);
            this.txtYemekAdi.Name = "txtYemekAdi";
            this.txtYemekAdi.Size = new System.Drawing.Size(203, 22);
            this.txtYemekAdi.TabIndex = 41;
            // 
            // lblAciklama
            // 
            this.lblAciklama.AutoSize = true;
            this.lblAciklama.Location = new System.Drawing.Point(7, 227);
            this.lblAciklama.Name = "lblAciklama";
            this.lblAciklama.Size = new System.Drawing.Size(60, 17);
            this.lblAciklama.TabIndex = 40;
            this.lblAciklama.Text = "Açıklama";
            // 
            // lblFiyat
            // 
            this.lblFiyat.AutoSize = true;
            this.lblFiyat.Location = new System.Drawing.Point(7, 165);
            this.lblFiyat.Name = "lblFiyat";
            this.lblFiyat.Size = new System.Drawing.Size(37, 17);
            this.lblFiyat.TabIndex = 35;
            this.lblFiyat.Text = "Fiyat";
            // 
            // lblKategori
            // 
            this.lblKategori.AutoSize = true;
            this.lblKategori.Location = new System.Drawing.Point(7, 97);
            this.lblKategori.Name = "lblKategori";
            this.lblKategori.Size = new System.Drawing.Size(58, 17);
            this.lblKategori.TabIndex = 34;
            this.lblKategori.Text = "Kategori";
            // 
            // lblYemekAdi
            // 
            this.lblYemekAdi.AutoSize = true;
            this.lblYemekAdi.Location = new System.Drawing.Point(7, 35);
            this.lblYemekAdi.Name = "lblYemekAdi";
            this.lblYemekAdi.Size = new System.Drawing.Size(71, 17);
            this.lblYemekAdi.TabIndex = 31;
            this.lblYemekAdi.Text = "Yemek Adı";
            // 
            // gridControl1
            // 
            this.gridControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            gridLevelNode1.RelationName = "Level1";
            this.gridControl1.LevelTree.Nodes.AddRange(new DevExpress.XtraGrid.GridLevelNode[] {
            gridLevelNode1});
            this.gridControl1.Location = new System.Drawing.Point(300, 0);
            this.gridControl1.MainView = this.gridView1;
            this.gridControl1.Name = "gridControl1";
            this.gridControl1.Size = new System.Drawing.Size(658, 535);
            this.gridControl1.TabIndex = 1;
            this.gridControl1.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.gridControl1.Click += new System.EventHandler(this.gridControl1_Click);
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridControl1;
            this.gridView1.Name = "gridView1";
            // 
            // yemek_işlemleri
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(958, 535);
            this.Controls.Add(this.gridControl1);
            this.Controls.Add(this.xtraTabControl1);
            this.Name = "yemek_işlemleri";
            this.Text = "yemek_işlemleri";
            this.Load += new System.EventHandler(this.yemek_işlemleri_Load);
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControl1)).EndInit();
            this.xtraTabControl1.ResumeLayout(false);
            this.xtraTabPage2.ResumeLayout(false);
            this.xtraTabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cbKategori.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFiyat.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYemekAdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraTab.XtraTabControl xtraTabControl1;
        private DevExpress.XtraTab.XtraTabPage xtraTabPage2;
        private DevExpress.XtraGrid.GridControl gridControl1;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraEditors.SimpleButton btnSil;
        private DevExpress.XtraEditors.SimpleButton btnTemizleSil;
        private DevExpress.XtraEditors.SimpleButton btnGuncelle;
        private DevExpress.XtraEditors.SimpleButton btnEkle;
        private System.Windows.Forms.RichTextBox txtAciklama;
        private DevExpress.XtraEditors.ComboBoxEdit cbKategori;
        private DevExpress.XtraEditors.TextEdit txtFiyat;
        private DevExpress.XtraEditors.TextEdit txtYemekAdi;
        private System.Windows.Forms.Label lblAciklama;
        private System.Windows.Forms.Label lblFiyat;
        private System.Windows.Forms.Label lblKategori;
        private System.Windows.Forms.Label lblYemekAdi;
    }
}