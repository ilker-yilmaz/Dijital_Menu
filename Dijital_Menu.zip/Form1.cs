﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : DevExpress.XtraBars.Ribbon.RibbonForm
    {
        //bağlantı cümleciğini yazıyoruz
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-UI4IIME2; Initial Catalog=DijitalMenu; Integrated Security=True");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            hizliErisim hizliErisim = new hizliErisim();
            hizliErisim.MdiParent = this;
            hizliErisim.Show();
        }

        private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            yemek_işlemleri ymk = new yemek_işlemleri();
            ymk.MdiParent = this;
            ymk.Show();
        }

        private void barButtonItem9_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

        }

        private void btnGuncelle_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            yemek_işlemleri ymk = new yemek_işlemleri();
            ymk.MdiParent = this;
            ymk.Show();
        }

        private void btnSil_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            yemek_işlemleri ymk = new yemek_işlemleri();
            ymk.MdiParent = this;
            ymk.Show();
        }

        private void barButtonItem4_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            Application.Exit();
        }
    }
}
