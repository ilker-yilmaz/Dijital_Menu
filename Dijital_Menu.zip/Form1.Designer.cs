﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.repositoryItemCalcEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.btnEkle = new DevExpress.XtraBars.BarButtonItem();
            this.btnGuncelle = new DevExpress.XtraBars.BarButtonItem();
            this.btnSil = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem3 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem6 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem7 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem8 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem9 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem10 = new DevExpress.XtraBars.BarButtonItem();
            this.bstHosgeldiniz = new DevExpress.XtraBars.BarStaticItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.barHeaderItem1 = new DevExpress.XtraBars.BarHeaderItem();
            this.rpAnaSayfa = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgrpMuhtesemUclu = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpgCikis = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpYemekler = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgMuhtesemUclu = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpMasalar = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgMasaİslemleri = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpMusteriHesap = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgMusteriHesap = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpRezervasyon = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgRezervasyon = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpPaketServis = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgPaketServis = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpMusteriler = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgMusteriler = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpKasa = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgKasaİslemleri = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpRaporlar = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgRaporlar = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.rpAyarlar = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.rpgAyarlar = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.xtraTabbedMdiManager1 = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemCalcEdit1
            // 
            this.repositoryItemCalcEdit1.AutoHeight = false;
            this.repositoryItemCalcEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemCalcEdit1.Name = "repositoryItemCalcEdit1";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ColorScheme = DevExpress.XtraBars.Ribbon.RibbonControlColorScheme.DarkBlue;
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.btnEkle,
            this.btnGuncelle,
            this.btnSil,
            this.barStaticItem1,
            this.barButtonItem1,
            this.barButtonItem2,
            this.barButtonItem3,
            this.barButtonItem4,
            this.barButtonItem5,
            this.barButtonItem6,
            this.barButtonItem7,
            this.barButtonItem8,
            this.barButtonItem9,
            this.barButtonItem10,
            this.bstHosgeldiniz,
            this.barEditItem1,
            this.barStaticItem2,
            this.barHeaderItem1});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.ribbonControl1.MaxItemId = 21;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.rpAnaSayfa,
            this.rpYemekler,
            this.rpMasalar,
            this.rpMusteriHesap,
            this.rpRezervasyon,
            this.rpPaketServis,
            this.rpMusteriler,
            this.rpKasa,
            this.rpRaporlar,
            this.rpAyarlar});
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.barStaticItem1);
            this.ribbonControl1.QuickToolbarItemLinks.Add(this.bstHosgeldiniz);
            this.ribbonControl1.Size = new System.Drawing.Size(1475, 201);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar1;
            // 
            // btnEkle
            // 
            this.btnEkle.Caption = "Yemek Ekle";
            this.btnEkle.Id = 2;
            this.btnEkle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnEkle.ImageOptions.Image")));
            this.btnEkle.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnEkle.ImageOptions.LargeImage")));
            this.btnEkle.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnEkle.ImageOptions.SvgImage")));
            this.btnEkle.Name = "btnEkle";
            this.btnEkle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // btnGuncelle
            // 
            this.btnGuncelle.Caption = "Yemek Güncelle";
            this.btnGuncelle.Id = 3;
            this.btnGuncelle.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnGuncelle.ImageOptions.Image")));
            this.btnGuncelle.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnGuncelle.ImageOptions.LargeImage")));
            this.btnGuncelle.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnGuncelle.ImageOptions.SvgImage")));
            this.btnGuncelle.Name = "btnGuncelle";
            this.btnGuncelle.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnGuncelle_ItemClick);
            // 
            // btnSil
            // 
            this.btnSil.Caption = "Yemek Sil";
            this.btnSil.Id = 4;
            this.btnSil.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSil.ImageOptions.Image")));
            this.btnSil.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("btnSil.ImageOptions.LargeImage")));
            this.btnSil.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("btnSil.ImageOptions.SvgImage")));
            this.btnSil.Name = "btnSil";
            this.btnSil.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.btnSil_ItemClick);
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "DİJİTAL MENÜ";
            this.barStaticItem1.Id = 5;
            this.barStaticItem1.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barStaticItem1.ImageOptions.SvgImage")));
            this.barStaticItem1.Name = "barStaticItem1";
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Rezervasyon Ekle";
            this.barButtonItem1.Id = 6;
            this.barButtonItem1.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem1.ImageOptions.Image")));
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Rezervasyon Güncelle";
            this.barButtonItem2.Id = 7;
            this.barButtonItem2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem2.ImageOptions.Image")));
            this.barButtonItem2.Name = "barButtonItem2";
            // 
            // barButtonItem3
            // 
            this.barButtonItem3.Caption = "Rezervasyon Sil";
            this.barButtonItem3.Id = 8;
            this.barButtonItem3.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("barButtonItem3.ImageOptions.Image")));
            this.barButtonItem3.Name = "barButtonItem3";
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "ÇIKIŞ";
            this.barButtonItem4.Id = 9;
            this.barButtonItem4.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem4.ImageOptions.SvgImage")));
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Caption = "Yemek Ekle";
            this.barButtonItem5.Id = 10;
            this.barButtonItem5.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem5.ImageOptions.SvgImage")));
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonItem6
            // 
            this.barButtonItem6.Caption = "Yemek Güncelle";
            this.barButtonItem6.Id = 11;
            this.barButtonItem6.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem6.ImageOptions.SvgImage")));
            this.barButtonItem6.Name = "barButtonItem6";
            // 
            // barButtonItem7
            // 
            this.barButtonItem7.Caption = "Yemek Sil";
            this.barButtonItem7.Id = 12;
            this.barButtonItem7.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem7.ImageOptions.SvgImage")));
            this.barButtonItem7.Name = "barButtonItem7";
            // 
            // barButtonItem8
            // 
            this.barButtonItem8.Caption = "Kapasite";
            this.barButtonItem8.Id = 13;
            this.barButtonItem8.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem8.ImageOptions.SvgImage")));
            this.barButtonItem8.Name = "barButtonItem8";
            // 
            // barButtonItem9
            // 
            this.barButtonItem9.Caption = "Servis Türü";
            this.barButtonItem9.Id = 14;
            this.barButtonItem9.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem9.ImageOptions.SvgImage")));
            this.barButtonItem9.Name = "barButtonItem9";
            this.barButtonItem9.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem9_ItemClick);
            // 
            // barButtonItem10
            // 
            this.barButtonItem10.Caption = "Durum";
            this.barButtonItem10.Id = 15;
            this.barButtonItem10.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("barButtonItem10.ImageOptions.SvgImage")));
            this.barButtonItem10.Name = "barButtonItem10";
            // 
            // bstHosgeldiniz
            // 
            this.bstHosgeldiniz.Caption = "Hoşgeldiniz...";
            this.bstHosgeldiniz.Id = 16;
            this.bstHosgeldiniz.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("bstHosgeldiniz.ImageOptions.Image")));
            this.bstHosgeldiniz.ImageOptions.LargeImage = ((System.Drawing.Image)(resources.GetObject("bstHosgeldiniz.ImageOptions.LargeImage")));
            this.bstHosgeldiniz.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("bstHosgeldiniz.ImageOptions.SvgImage")));
            this.bstHosgeldiniz.Name = "bstHosgeldiniz";
            this.bstHosgeldiniz.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // barEditItem1
            // 
            this.barEditItem1.Caption = "barEditItem1";
            this.barEditItem1.Edit = this.repositoryItemCalcEdit1;
            this.barEditItem1.Id = 17;
            this.barEditItem1.Name = "barEditItem1";
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "İLKER YILMAZ";
            this.barStaticItem2.Id = 18;
            this.barStaticItem2.Name = "barStaticItem2";
            // 
            // barHeaderItem1
            // 
            this.barHeaderItem1.Appearance.BackColor = System.Drawing.Color.Red;
            this.barHeaderItem1.Appearance.ForeColor = System.Drawing.Color.Aqua;
            this.barHeaderItem1.Appearance.Options.UseBackColor = true;
            this.barHeaderItem1.Appearance.Options.UseForeColor = true;
            this.barHeaderItem1.Caption = "Fırat Üniversitesi Yazılım Mühendisliği Otomasyon Projesi";
            this.barHeaderItem1.Id = 19;
            this.barHeaderItem1.Name = "barHeaderItem1";
            // 
            // rpAnaSayfa
            // 
            this.rpAnaSayfa.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpAnaSayfa.Appearance.Options.UseFont = true;
            this.rpAnaSayfa.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgrpMuhtesemUclu,
            this.ribbonPageGroup2,
            this.rpgCikis});
            this.rpAnaSayfa.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpAnaSayfa.ImageOptions.Image")));
            this.rpAnaSayfa.Name = "rpAnaSayfa";
            this.rpAnaSayfa.Text = "Anasayfa";
            // 
            // rpgrpMuhtesemUclu
            // 
            this.rpgrpMuhtesemUclu.ItemLinks.Add(this.btnEkle);
            this.rpgrpMuhtesemUclu.ItemLinks.Add(this.btnGuncelle);
            this.rpgrpMuhtesemUclu.ItemLinks.Add(this.btnSil);
            this.rpgrpMuhtesemUclu.Name = "rpgrpMuhtesemUclu";
            this.rpgrpMuhtesemUclu.Text = "Muhteşem Üçlü";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem1);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem2);
            this.ribbonPageGroup2.ItemLinks.Add(this.barButtonItem3);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Rezervasyon";
            // 
            // rpgCikis
            // 
            this.rpgCikis.ItemLinks.Add(this.barButtonItem4);
            this.rpgCikis.Name = "rpgCikis";
            // 
            // rpYemekler
            // 
            this.rpYemekler.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpYemekler.Appearance.Options.UseFont = true;
            this.rpYemekler.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgMuhtesemUclu});
            this.rpYemekler.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("rpYemekler.ImageOptions.SvgImage")));
            this.rpYemekler.Name = "rpYemekler";
            this.rpYemekler.Text = "Yemekler";
            // 
            // rpgMuhtesemUclu
            // 
            this.rpgMuhtesemUclu.ItemLinks.Add(this.barButtonItem5);
            this.rpgMuhtesemUclu.ItemLinks.Add(this.barButtonItem6);
            this.rpgMuhtesemUclu.ItemLinks.Add(this.barButtonItem7);
            this.rpgMuhtesemUclu.Name = "rpgMuhtesemUclu";
            this.rpgMuhtesemUclu.Text = "Muhteşem Üçlü";
            // 
            // rpMasalar
            // 
            this.rpMasalar.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpMasalar.Appearance.Options.UseFont = true;
            this.rpMasalar.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgMasaİslemleri});
            this.rpMasalar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpMasalar.ImageOptions.Image")));
            this.rpMasalar.Name = "rpMasalar";
            this.rpMasalar.Text = "Masalar";
            // 
            // rpgMasaİslemleri
            // 
            this.rpgMasaİslemleri.ItemLinks.Add(this.barButtonItem8);
            this.rpgMasaİslemleri.ItemLinks.Add(this.barButtonItem9);
            this.rpgMasaİslemleri.ItemLinks.Add(this.barButtonItem10);
            this.rpgMasaİslemleri.Name = "rpgMasaİslemleri";
            this.rpgMasaİslemleri.Text = "Masa İşlemleri";
            // 
            // rpMusteriHesap
            // 
            this.rpMusteriHesap.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpMusteriHesap.Appearance.Options.UseFont = true;
            this.rpMusteriHesap.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgMusteriHesap});
            this.rpMusteriHesap.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpMusteriHesap.ImageOptions.Image")));
            this.rpMusteriHesap.Name = "rpMusteriHesap";
            this.rpMusteriHesap.Text = "Müşteri Hesap";
            // 
            // rpgMusteriHesap
            // 
            this.rpgMusteriHesap.Name = "rpgMusteriHesap";
            this.rpgMusteriHesap.Text = "Müşteri Hesap";
            // 
            // rpRezervasyon
            // 
            this.rpRezervasyon.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpRezervasyon.Appearance.Options.UseFont = true;
            this.rpRezervasyon.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgRezervasyon});
            this.rpRezervasyon.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpRezervasyon.ImageOptions.Image")));
            this.rpRezervasyon.Name = "rpRezervasyon";
            this.rpRezervasyon.Text = "Rezervasyon";
            // 
            // rpgRezervasyon
            // 
            this.rpgRezervasyon.Name = "rpgRezervasyon";
            this.rpgRezervasyon.Text = "Rezervasyon";
            // 
            // rpPaketServis
            // 
            this.rpPaketServis.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpPaketServis.Appearance.Options.UseFont = true;
            this.rpPaketServis.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgPaketServis});
            this.rpPaketServis.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpPaketServis.ImageOptions.Image")));
            this.rpPaketServis.Name = "rpPaketServis";
            this.rpPaketServis.Text = "Paket Servis";
            // 
            // rpgPaketServis
            // 
            this.rpgPaketServis.Name = "rpgPaketServis";
            this.rpgPaketServis.Text = "Paket Servis";
            // 
            // rpMusteriler
            // 
            this.rpMusteriler.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpMusteriler.Appearance.Options.UseFont = true;
            this.rpMusteriler.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgMusteriler});
            this.rpMusteriler.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpMusteriler.ImageOptions.Image")));
            this.rpMusteriler.Name = "rpMusteriler";
            this.rpMusteriler.Text = "Müşteriler";
            // 
            // rpgMusteriler
            // 
            this.rpgMusteriler.Name = "rpgMusteriler";
            this.rpgMusteriler.Text = "Müşteriler";
            // 
            // rpKasa
            // 
            this.rpKasa.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpKasa.Appearance.Options.UseFont = true;
            this.rpKasa.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgKasaİslemleri});
            this.rpKasa.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpKasa.ImageOptions.Image")));
            this.rpKasa.Name = "rpKasa";
            this.rpKasa.Text = "Kasa İşlemleri";
            // 
            // rpgKasaİslemleri
            // 
            this.rpgKasaİslemleri.Name = "rpgKasaİslemleri";
            this.rpgKasaİslemleri.Text = "Kasa İşlemleri";
            // 
            // rpRaporlar
            // 
            this.rpRaporlar.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpRaporlar.Appearance.Options.UseFont = true;
            this.rpRaporlar.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgRaporlar});
            this.rpRaporlar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpRaporlar.ImageOptions.Image")));
            this.rpRaporlar.Name = "rpRaporlar";
            this.rpRaporlar.Text = "Raporlar";
            // 
            // rpgRaporlar
            // 
            this.rpgRaporlar.Name = "rpgRaporlar";
            this.rpgRaporlar.Text = "Raporlar";
            // 
            // rpAyarlar
            // 
            this.rpAyarlar.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rpAyarlar.Appearance.Options.UseFont = true;
            this.rpAyarlar.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.rpgAyarlar});
            this.rpAyarlar.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("rpAyarlar.ImageOptions.Image")));
            this.rpAyarlar.Name = "rpAyarlar";
            this.rpAyarlar.Text = "Ayarlar";
            // 
            // rpgAyarlar
            // 
            this.rpgAyarlar.Name = "rpgAyarlar";
            this.rpgAyarlar.Text = "Ayarlar";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.ItemLinks.Add(this.barStaticItem2);
            this.ribbonStatusBar1.ItemLinks.Add(this.barHeaderItem1);
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 680);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(1475, 37);
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "ribbonPageGroup1";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "ribbonPage1";
            // 
            // xtraTabbedMdiManager1
            // 
            this.xtraTabbedMdiManager1.MdiParent = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1475, 717);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Ribbon = this.ribbonControl1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StatusBar = this.ribbonStatusBar1;
            this.Text = "Dijital Menü";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCalcEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraBars.BarButtonItem btnEkle;
        private DevExpress.XtraBars.BarButtonItem btnGuncelle;
        private DevExpress.XtraBars.BarButtonItem btnSil;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpAnaSayfa;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgrpMuhtesemUclu;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpYemekler;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMuhtesemUclu;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpMasalar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMasaİslemleri;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpMusteriHesap;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMusteriHesap;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpRezervasyon;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgRezervasyon;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpPaketServis;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgPaketServis;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpMusteriler;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgMusteriler;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpKasa;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgKasaİslemleri;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpRaporlar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgRaporlar;
        private DevExpress.XtraBars.Ribbon.RibbonPage rpAyarlar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgAyarlar;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
        private DevExpress.XtraBars.BarButtonItem barButtonItem3;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonItem6;
        private DevExpress.XtraBars.BarButtonItem barButtonItem7;
        private DevExpress.XtraBars.BarButtonItem barButtonItem8;
        private DevExpress.XtraBars.BarButtonItem barButtonItem9;
        private DevExpress.XtraBars.BarButtonItem barButtonItem10;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup rpgCikis;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTabbedMdiManager1;
        private DevExpress.XtraBars.BarStaticItem bstHosgeldiniz;
        private DevExpress.XtraBars.BarEditItem barEditItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCalcEdit repositoryItemCalcEdit1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.BarHeaderItem barHeaderItem1;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
    }
}

