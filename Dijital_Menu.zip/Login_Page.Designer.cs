﻿namespace $safeprojectname$
{
    partial class Login_Page
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_Page));
            this.btnGiris = new DevExpress.XtraEditors.SimpleButton();
            this.lblKullaniciAdi = new DevExpress.XtraEditors.LabelControl();
            this.lblSifre = new DevExpress.XtraEditors.LabelControl();
            this.textBox_K_adi = new DevExpress.XtraEditors.TextEdit();
            this.textBox_password = new DevExpress.XtraEditors.TextEdit();
            this.checkEdit1 = new DevExpress.XtraEditors.CheckEdit();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.sidePanel1 = new DevExpress.XtraEditors.SidePanel();
            this.sidePanel2 = new DevExpress.XtraEditors.SidePanel();
            this.behaviorManager1 = new DevExpress.Utils.Behaviors.BehaviorManager();
            this.btnSifremiUnuttum = new DevExpress.XtraEditors.SimpleButton();
            this.btnGorunurYap = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.textBox_K_adi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox_password.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).BeginInit();
            this.sidePanel1.SuspendLayout();
            this.sidePanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGiris
            // 
            this.btnGiris.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("simpleButton1.Appearance.Font")));
            this.btnGiris.Appearance.ForeColor = ((System.Drawing.Color)(resources.GetObject("simpleButton1.Appearance.ForeColor")));
            this.btnGiris.Appearance.Options.UseFont = true;
            this.btnGiris.Appearance.Options.UseForeColor = true;
            resources.ApplyResources(this.btnGiris, "btnGiris");
            this.btnGiris.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGiris.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image")));
            this.btnGiris.Name = "btnGiris";
            this.btnGiris.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // lblKullaniciAdi
            // 
            this.lblKullaniciAdi.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("lblKullaniciAdi.Appearance.Font")));
            this.lblKullaniciAdi.Appearance.ForeColor = ((System.Drawing.Color)(resources.GetObject("lblKullaniciAdi.Appearance.ForeColor")));
            this.lblKullaniciAdi.Appearance.Options.UseFont = true;
            this.lblKullaniciAdi.Appearance.Options.UseForeColor = true;
            resources.ApplyResources(this.lblKullaniciAdi, "lblKullaniciAdi");
            this.lblKullaniciAdi.Name = "lblKullaniciAdi";
            // 
            // lblSifre
            // 
            this.lblSifre.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("lblSifre.Appearance.Font")));
            this.lblSifre.Appearance.ForeColor = ((System.Drawing.Color)(resources.GetObject("lblSifre.Appearance.ForeColor")));
            this.lblSifre.Appearance.Options.UseFont = true;
            this.lblSifre.Appearance.Options.UseForeColor = true;
            resources.ApplyResources(this.lblSifre, "lblSifre");
            this.lblSifre.Name = "lblSifre";
            // 
            // textBox_K_adi
            // 
            this.textBox_K_adi.Cursor = System.Windows.Forms.Cursors.IBeam;
            resources.ApplyResources(this.textBox_K_adi, "textBox_K_adi");
            this.textBox_K_adi.Name = "textBox_K_adi";
            this.textBox_K_adi.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("textBox_K_adi.Properties.Appearance.Font")));
            this.textBox_K_adi.Properties.Appearance.Options.UseFont = true;
            this.textBox_K_adi.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textBox_K_adi.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            // 
            // textBox_password
            // 
            this.textBox_password.Cursor = System.Windows.Forms.Cursors.IBeam;
            resources.ApplyResources(this.textBox_password, "textBox_password");
            this.textBox_password.Name = "textBox_password";
            this.textBox_password.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("textBox_password.Properties.Appearance.Font")));
            this.textBox_password.Properties.Appearance.Options.UseFont = true;
            this.textBox_password.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.textBox_password.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.textBox_password.Properties.UseSystemPasswordChar = true;
            // 
            // checkEdit1
            // 
            this.checkEdit1.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.checkEdit1, "checkEdit1");
            this.checkEdit1.Name = "checkEdit1";
            this.checkEdit1.Properties.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("checkEdit1.Properties.Appearance.Font")));
            this.checkEdit1.Properties.Appearance.ForeColor = ((System.Drawing.Color)(resources.GetObject("checkEdit1.Properties.Appearance.ForeColor")));
            this.checkEdit1.Properties.Appearance.Options.UseFont = true;
            this.checkEdit1.Properties.Appearance.Options.UseForeColor = true;
            this.checkEdit1.Properties.Caption = resources.GetString("checkEdit1.Properties.Caption");
            this.checkEdit1.CheckedChanged += new System.EventHandler(this.checkEdit1_CheckedChanged);
            // 
            // simpleButton2
            // 
            this.simpleButton2.Appearance.BackColor = ((System.Drawing.Color)(resources.GetObject("simpleButton2.Appearance.BackColor")));
            this.simpleButton2.Appearance.BackColor2 = ((System.Drawing.Color)(resources.GetObject("simpleButton2.Appearance.BackColor2")));
            this.simpleButton2.Appearance.Options.UseBackColor = true;
            resources.ApplyResources(this.simpleButton2, "simpleButton2");
            this.simpleButton2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.simpleButton2.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton2.ImageOptions.Image")));
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // sidePanel1
            // 
            this.sidePanel1.Appearance.BackColor = ((System.Drawing.Color)(resources.GetObject("sidePanel1.Appearance.BackColor")));
            this.sidePanel1.Appearance.Options.UseBackColor = true;
            this.sidePanel1.Controls.Add(this.btnSifremiUnuttum);
            this.sidePanel1.Controls.Add(this.lblKullaniciAdi);
            this.sidePanel1.Controls.Add(this.lblSifre);
            resources.ApplyResources(this.sidePanel1, "sidePanel1");
            this.sidePanel1.Name = "sidePanel1";
            // 
            // sidePanel2
            // 
            this.sidePanel2.Appearance.BackColor = ((System.Drawing.Color)(resources.GetObject("sidePanel2.Appearance.BackColor")));
            this.sidePanel2.Appearance.Options.UseBackColor = true;
            this.sidePanel2.Controls.Add(this.btnGorunurYap);
            this.sidePanel2.Controls.Add(this.btnGiris);
            this.sidePanel2.Controls.Add(this.simpleButton2);
            this.sidePanel2.Controls.Add(this.checkEdit1);
            this.sidePanel2.Controls.Add(this.textBox_password);
            this.sidePanel2.Controls.Add(this.textBox_K_adi);
            resources.ApplyResources(this.sidePanel2, "sidePanel2");
            this.sidePanel2.Name = "sidePanel2";
            // 
            // btnSifremiUnuttum
            // 
            this.btnSifremiUnuttum.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.btnSifremiUnuttum, "btnSifremiUnuttum");
            this.btnSifremiUnuttum.Name = "btnSifremiUnuttum";
            this.btnSifremiUnuttum.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // btnGorunurYap
            // 
            this.btnGorunurYap.Appearance.Font = ((System.Drawing.Font)(resources.GetObject("simpleButton1.Appearance.Font1")));
            this.btnGorunurYap.Appearance.ForeColor = ((System.Drawing.Color)(resources.GetObject("simpleButton1.Appearance.ForeColor1")));
            this.btnGorunurYap.Appearance.Options.UseFont = true;
            this.btnGorunurYap.Appearance.Options.UseForeColor = true;
            resources.ApplyResources(this.btnGorunurYap, "btnGorunurYap");
            this.btnGorunurYap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGorunurYap.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.ImageOptions.Image1")));
            this.btnGorunurYap.Name = "btnGorunurYap";
            this.btnGorunurYap.Click += new System.EventHandler(this.simpleButton1_Click_1);
            // 
            // Login_Page
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayoutStore = System.Windows.Forms.ImageLayout.Tile;
            this.BackgroundImageStore = global::$safeprojectname$.Properties.Resources.yemek;
            this.Controls.Add(this.sidePanel2);
            this.Controls.Add(this.sidePanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Login_Page";
            this.Load += new System.EventHandler(this.Login_Page_Load);
            ((System.ComponentModel.ISupportInitialize)(this.textBox_K_adi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox_password.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.checkEdit1.Properties)).EndInit();
            this.sidePanel1.ResumeLayout(false);
            this.sidePanel1.PerformLayout();
            this.sidePanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.behaviorManager1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnGiris;
        private DevExpress.XtraEditors.LabelControl lblKullaniciAdi;
        private DevExpress.XtraEditors.LabelControl lblSifre;
        private DevExpress.XtraEditors.TextEdit textBox_K_adi;
        private DevExpress.XtraEditors.TextEdit textBox_password;
        private DevExpress.XtraEditors.CheckEdit checkEdit1;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SidePanel sidePanel1;
        private DevExpress.XtraEditors.SidePanel sidePanel2;
        private DevExpress.Utils.Behaviors.BehaviorManager behaviorManager1;
        private DevExpress.XtraEditors.SimpleButton btnSifremiUnuttum;
        private DevExpress.XtraEditors.SimpleButton btnGorunurYap;
    }
}