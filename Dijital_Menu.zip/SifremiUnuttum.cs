﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Mail; //mail gönderebilmek için gerekli olan kütüphane
using System.Windows.Forms;
namespace $safeprojectname$
{
    public partial class SifremiUnuttum : DevExpress.XtraEditors.XtraForm
    {
        //SQL ile bağlantı

        //bağlantı cümleciğini yazıyoruz
        SqlConnection conn = new SqlConnection("Data Source=LAPTOP-UI4IIME2; Initial Catalog=DijitalMenu; Integrated Security=True");

        public SifremiUnuttum()
        {
            InitializeComponent();
        }

        private void simpleButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void SifremiUnuttum_Load(object sender, EventArgs e)
        {

        }

        public bool Gonder(string konu, string icerik)
        {
            MailMessage ePosta = new MailMessage();

            ePosta.From = new MailAddress("ilkery549@gmail.com");//buraya kendi gmail hesabınız
            //
            ePosta.To.Add(txtEmail.Text);//bura şifre unutanın maili textboxdan çektik.
            ;

            ePosta.Subject = konu; //butonda veri tabanı çekdikden sonra aldımız değer konu değeri
            //
            ePosta.Body = icerik;  // buda şifremiz
            //
            SmtpClient smtp = new SmtpClient();
            //
            smtp.Credentials = new System.Net.NetworkCredential("ilkery549@gmail.com", "ilker123ilker");
            //kendi gmail hesabiniz var şifresi
            smtp.Port = 587;
            smtp.Host = "smtp.gmail.com";
            smtp.EnableSsl = true;
            object userState = ePosta;
            bool kontrol = true;
            try
            {
                smtp.SendAsync(ePosta, (object)ePosta);
            }
            catch (SmtpException ex)
            {
                kontrol = false;
                System.Windows.Forms.MessageBox.Show(ex.Message, "Mail Gönderme Hatasi");
            }
            return kontrol;

        }

        private void simpleButton3_Click(object sender, EventArgs e)
        {
            {
                if (conn.State == ConnectionState.Closed) //eğer bağlantı kapalıysa
                {
                    conn.Open(); //bağlantıyı aç
                }

                SqlCommand com = new SqlCommand("Select * from Login where SifreKullaniciAdi='" + txtKullaniciAdi.Text.ToString() +
                    "'and SifreEmail='" + txtEmail.Text.ToString() + "'", conn);
                //burada veritabanina kodlayarak yazdımız şifrelerin kodlarını karşılaştırdık
                SqlDataReader oku = com.ExecuteReader();
                if (oku.Read())
                {
                    //burada verdiği tc ve mail doğruysa gireceği için şifreyi veritabanından çekip gönder fonksiyonunu kullanarak göndereceğiz

                    string Sifre = oku["Sifre"].ToString();
                    //veritabanından çekdik            
                    MessageBox.Show("Girmiş Oldunuz Bilgiler Uyuşuyor Şifreniz Mail adresinize yollanıyor");
                    Gonder("Unutmuş Olduğunuz Şifreniz Ektedir", txtKullaniciAdi.Text);
                    //gönder paremetresi ile içeriğe 2 string değer yolladık biri mesajımız öbürü şifresi
                    conn.Close();

                    //işlem başarılıysa login ekranına geri dönüyoruz.
                    Login_Page lp = new Login_Page();
                    lp.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Bilgileriniz Uyuşmadı");
                }
                conn.Close();


            }
        }
    }
}